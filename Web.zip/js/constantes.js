export const LOCALURI = "http://localhost:8081";
export const REMOTEURI ="https://clubbaloncestobollullos.eu-west-1.elasticbeanstalk.com"
